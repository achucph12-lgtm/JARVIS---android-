# JARVIS Android V1 — Phone-only build

This is a native Android starter project. It has a dark luxury interface, English/Tamil speech recognition via Android's speech recognizer, text-to-speech, task and note storage on-device, and a simple local command parser.

## Build an APK without a PC

1. On your Android phone, open Chrome and sign in to GitHub.
2. Create a new repository named `jarvis-android`. Set it to **Private** if you prefer.
3. Upload the contents of this project ZIP into the repository, preserving folder paths. GitHub's mobile website may be easier in Chrome with **Desktop site** enabled. The `.github/workflows/build-apk.yml` file must be in the repository at exactly that path.
4. Open the repository's **Actions** tab. If GitHub asks, enable Actions.
5. Select **Build JARVIS APK** and tap **Run workflow**. Alternatively, the workflow starts automatically after a push to `main`.
6. Wait for the run to finish successfully.
7. Open the completed run, scroll to **Artifacts**, and download `JARVIS-Android-debug`.
8. Extract the artifact ZIP on your phone. Tap `app-debug.apk` to install it. Android may ask you to allow installs from that browser or file manager; only allow this for the APK you built from your own repository.

## First launch
- Allow microphone access when you use the SPEAK button.
- Choose English or Tamil.
- Try `help`, `add task study maths`, `show tasks`, `save note: GENAURA idea`, `show notes`, `time`, and `date`.
- Notes and tasks are stored locally in the app's private preferences.

## Current limitations
- This is a starter, not a full conversational AI. No OpenAI API key or cloud AI is included.
- Speech recognition availability and Tamil voices depend on Android speech services and installed language packs.
- The app does not run a wake word continuously in the background.
- No Gmail, Calendar, GENAURA, Qikink or general phone-control integration yet.
- The APK produced by this workflow is a debug build for testing, not a Play Store release.

## Important
Do not put API secrets in Android source code or commit them to a public repository. A later AI integration should use a small authenticated backend so the API key is not exposed in the APK.
