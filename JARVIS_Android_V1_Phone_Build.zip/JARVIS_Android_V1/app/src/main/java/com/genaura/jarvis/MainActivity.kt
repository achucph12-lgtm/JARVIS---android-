package com.genaura.jarvis

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import android.text.InputType
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val bg = Color.rgb(8, 10, 15)
    private val panel = Color.rgb(17, 21, 29)
    private val cyan = Color.rgb(111, 207, 255)
    private val muted = Color.rgb(151, 164, 181)
    private val white = Color.rgb(238, 243, 250)
    private lateinit var root: LinearLayout
    private lateinit var chat: LinearLayout
    private lateinit var taskBox: LinearLayout
    private lateinit var noteBox: LinearLayout
    private lateinit var input: EditText
    private lateinit var statusText: TextView
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var language = "en"
    private val prefs by lazy { getSharedPreferences("jarvis_data", MODE_PRIVATE) }
    private val tasks = mutableListOf<String>()
    private val notes = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() or
                View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
        loadData()
        tts = TextToSpeech(this, this)
        buildUi()
        addMessage("JARVIS", "Systems online. Vanakkam. How can I assist you?")
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts.language = Locale("en", "IN")
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(15), dp(16), dp(15))
        setBackgroundColor(panel)
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(panel)
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), Color.rgb(38, 53, 69))
        }
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(12))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(7), 0, dp(18))
        }
        val brand = text("◉  J.A.R.V.I.S.", 19f, cyan, true)
        brand.letterSpacing = .12f
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        statusText = text("● ONLINE", 11f, Color.rgb(89, 220, 170), true)
        header.addView(statusText)
        content.addView(header)

        content.addView(text("PERSONAL INTELLIGENCE SYSTEM", 10f, muted, true))
        val title = text("Good day.", 30f, white, true)
        title.setPadding(0, dp(5), 0, dp(2))
        content.addView(title)
        val date = SimpleDateFormat("EEEE, dd MMMM", Locale.getDefault()).format(Date())
        content.addView(text(date, 13f, muted))
        spacer(content, 18)

        val core = card()
        core.gravity = Gravity.CENTER_HORIZONTAL
        val orb = TextView(this).apply {
            text = "J"
            textSize = 43f
            gravity = Gravity.CENTER
            setTextColor(cyan)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.rgb(13, 32, 48))
                setStroke(dp(2), cyan)
            }
            elevation = dp(10).toFloat()
        }
        core.addView(orb, LinearLayout.LayoutParams(dp(112), dp(112)).apply {
            gravity = Gravity.CENTER
            bottomMargin = dp(13)
        })
        val coreLabel = text("JARVIS  /  READY", 12f, cyan, true)
        coreLabel.letterSpacing = .16f
        core.addView(coreLabel)
        core.addView(text("Your personal assistant is standing by.", 12f, muted).apply {
            setPadding(0, dp(7), 0, dp(12))
        })
        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        core.addView(chat)
        content.addView(core)
        spacer(content, 15)

        val commandCard = card()
        commandCard.addView(text("COMMAND CONSOLE", 10f, cyan, true))
        input = EditText(this).apply {
            hint = "Ask JARVIS anything..."
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 15f
            singleLine = true
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(8, 13, 20))
                cornerRadius = dp(10).toFloat()
                setStroke(dp(1), Color.rgb(48, 72, 91))
            }
        }
        commandCard.addView(input, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(10) })
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val send = button("SEND")
        val mic = button("🎙  SPEAK")
        buttons.addView(send, LinearLayout.LayoutParams(0, dp(46), 1f).apply { rightMargin = dp(6) })
        buttons.addView(mic, LinearLayout.LayoutParams(0, dp(46), 1f).apply { leftMargin = dp(6) })
        commandCard.addView(buttons, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(9) })
        val langRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        langRow.addView(text("VOICE LANGUAGE", 10f, muted), LinearLayout.LayoutParams(0, -2, 1f))
        val lang = Spinner(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("English", "தமிழ்"))
        lang.adapter = adapter
        lang.setSelection(0)
        lang.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, pos: Int, id: Long) {
                language = if (pos == 1) "ta" else "en"
                if (ttsReady) tts.language = if (language == "ta") Locale("ta", "IN") else Locale("en", "IN")
            }
            override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
        }
        langRow.addView(lang, LinearLayout.LayoutParams(dp(125), dp(42)))
        commandCard.addView(langRow)
        content.addView(commandCard)
        send.setOnClickListener { process(input.text.toString()) }
        input.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_SEND) { process(input.text.toString()); true } else false
        }
        mic.setOnClickListener { listen() }
        spacer(content, 15)

        val taskCard = card()
        taskCard.addView(text("TASK MANAGER", 11f, cyan, true))
        taskBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        taskCard.addView(taskBox)
        content.addView(taskCard)
        spacer(content, 12)

        val noteCard = card()
        noteCard.addView(text("PERSONAL NOTES", 11f, cyan, true))
        noteBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        noteCard.addView(noteBox)
        content.addView(noteCard)
        spacer(content, 14)
        content.addView(text("JARVIS V1.0  •  LOCAL STARTER  •  PRIVATE ON-DEVICE NOTES", 9f, muted).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(8))
        })
        setContentView(root)
        renderTasks()
        renderNotes()
    }

    private fun spacer(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun button(label: String): Button = Button(this).apply {
        text = label
        textSize = 12f
        setTextColor(white)
        isAllCaps = false
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.rgb(24, 69, 98))
            cornerRadius = dp(11).toFloat()
            setStroke(dp(1), Color.rgb(73, 153, 196))
        }
    }

    private fun addMessage(who: String, message: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(10, 22, 33))
                cornerRadius = dp(10).toFloat()
                setStroke(dp(1), Color.rgb(35, 57, 75))
            }
        }
        box.addView(text(who, 9f, cyan, true))
        box.addView(text(message, 13f, white).apply { setPadding(0, dp(3), 0, 0) })
        chat.addView(box, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
    }

    private fun process(raw: String) {
        val command = raw.trim()
        if (command.isEmpty()) return
        input.setText("")
        addMessage("YOU", command)
        val low = command.lowercase(Locale.ROOT)
        val tamil = command.any { it in '\u0B80'..'\u0BFF' }
        val response = when {
            low == "help" || low == "உதவி" ->
                "Try: add task study maths, show tasks, save note: project idea, show notes, time, or date."
            low.startsWith("add task ") || low.startsWith("create task ") || low.startsWith("டாஸ்க் சேர் ") -> {
                val item = command.substringAfter(" ", "").substringAfter(" ", "").trim()
                if (item.isNotEmpty()) { tasks.add(item); saveData(); renderTasks(); if (tamil) "வேலை சேர்க்கப்பட்டது: $item" else "Task added: $item" }
                else "Please provide a task name."
            }
            low.startsWith("save note:") || low.startsWith("note:") || low.startsWith("குறிப்பு சேமி ") -> {
                val item = command.substringAfter(":").ifBlank { command.substringAfter(" ", "") }.trim()
                if (item.isNotEmpty()) { notes.add(item); saveData(); renderNotes(); if (tamil) "குறிப்பு சேமிக்கப்பட்டது." else "Note saved." }
                else "Please provide note text."
            }
            low.contains("show tasks") || low.contains("list tasks") || low.contains("வேலைகள்") ->
                if (tasks.isEmpty()) "No saved tasks yet." else tasks.joinToString(". ")
            low.contains("show notes") || low.contains("list notes") || low.contains("குறிப்புகள்") ->
                if (notes.isEmpty()) "No saved notes yet." else notes.joinToString(". ")
            low.contains("time") || low.contains("நேரம்") ->
                SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()).let { if (tamil) "இப்போது நேரம் $it" else "The time is $it" }
            low.contains("date") || low.contains("today") || low.contains("தேதி") ->
                SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(Date()).let { if (tamil) "இன்றைய தேதி $it" else "Today's date is $it" }
            else -> if (tamil) "இந்த கட்டளையை இன்னும் கற்றுக்கொள்ளவில்லை. உதவி என்று சொல்லுங்கள்." else "I'm online. This starter version does not understand that command yet. Say help to see available commands."
        }
        addMessage("JARVIS", response)
        speak(response, tamil)
    }

    private fun listen() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (language == "ta") "ta-IN" else "en-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, if (language == "ta") "JARVIS-க்கு பேசுங்கள்" else "Speak to JARVIS")
        }
        try { startActivityForResult(intent, 701) }
        catch (_: Exception) { Toast.makeText(this, "Speech recognition is unavailable on this device.", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 701 && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (!words.isNullOrEmpty()) process(words[0])
        }
    }

    private fun speak(message: String, tamil: Boolean) {
        if (ttsReady) {
            tts.language = if (tamil) Locale("ta", "IN") else Locale("en", "IN")
            tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
        }
    }

    private fun saveData() {
        prefs.edit().putString("tasks", JSONArray(tasks).toString())
            .putString("notes", JSONArray(notes).toString()).apply()
    }

    private fun loadData() {
        try {
            val a = JSONArray(prefs.getString("tasks", "[]"))
            for (i in 0 until a.length()) tasks.add(a.getString(i))
            val b = JSONArray(prefs.getString("notes", "[]"))
            for (i in 0 until b.length()) notes.add(b.getString(i))
        } catch (_: Exception) { }
    }

    private fun renderTasks() {
        if (!::taskBox.isInitialized) return
        taskBox.removeAllViews()
        if (tasks.isEmpty()) taskBox.addView(text("No tasks yet. Add one using “add task ...”.", 12f, muted))
        tasks.takeLast(12).reversed().forEach { item ->
            taskBox.addView(text("•  $item", 13f, white).apply { setPadding(0, dp(7), 0, dp(7)) })
        }
    }

    private fun renderNotes() {
        if (!::noteBox.isInitialized) return
        noteBox.removeAllViews()
        if (notes.isEmpty()) noteBox.addView(text("No notes yet. Try “save note: ...”.", 12f, muted))
        notes.takeLast(12).reversed().forEach { item ->
            noteBox.addView(text("◇  $item", 13f, white).apply { setPadding(0, dp(7), 0, dp(7)) })
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
